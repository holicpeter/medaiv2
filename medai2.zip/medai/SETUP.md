# MedAI — HealthKit Sync Setup

## ⚠️ Important: Expo Dev Client required

`react-native-health` uses native iOS modules — it does NOT work with Expo Go.
You need to build a Dev Client (one-time, ~10 min).

---

## Step 1 — Install dependencies

```bash
npm install
npm install react-native-health
npx expo install expo-dev-client expo-build-properties
```

## Step 2 — Set environment variables

```bash
cp .env.example .env
# Fill in:
# EXPO_PUBLIC_SUPABASE_URL=https://mkeigajyywkmaspsrugp.supabase.co
# EXPO_PUBLIC_SUPABASE_ANON_KEY=<your anon key from supabase.com>
# EXPO_PUBLIC_ANTHROPIC_API_KEY=sk-ant-...
```

## Step 3 — Prebuild (generates ios/ folder)

```bash
npx expo prebuild --platform ios
```

This creates the `ios/` folder with HealthKit entitlement already configured via app.json.

## Step 4 — Install CocoaPods

```bash
cd ios && pod install && cd ..
```

## Step 5 — Build Dev Client

```bash
# Option A: Local build (requires Xcode)
npx expo run:ios

# Option B: EAS cloud build (no Xcode needed)
npx eas-cli@latest build --platform ios --profile development
```

## Step 6 — Run

```bash
npx expo start --dev-client
```

Scan QR with your Dev Client app on iPhone.

---

## What happens on first launch

1. App shows onboarding (Steps 1–4)
2. Step 4: iOS HealthKit permission dialog appears
3. User grants permissions
4. `useHealthSync` auto-runs on mount:
   - Fetches 30 days of biometrics from HealthKit
   - Normalizes to FHIR Observations
   - Upserts to Supabase `observations` table
   - Loads into Zustand store → Overview + Vitals screens update
5. Every time app comes to foreground: re-syncs if >15 min since last sync

---

## Supabase project

- Project: MEDICALAI
- URL: https://mkeigajyywkmaspsrugp.supabase.co
- Region: eu-west-1 (Ireland)
- Schema: 11 migrations applied, all security checks passing

Get your anon key from:
supabase.com → MEDICALAI → Settings → API → Project API keys → anon / public
