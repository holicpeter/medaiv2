import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Colors, Radius } from '@/constants/theme';
export default function ScanTab() {
  return (
    <View style={s.root}>
      <Text style={s.icon}>📸</Text>
      <Text style={s.text}>OCR Scanner</Text>
      <Text style={s.sub}>Scan lab results — Phase 2</Text>
      <TouchableOpacity style={s.btn}>
        <Text style={s.btnText}>Open camera</Text>
      </TouchableOpacity>
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex:1, backgroundColor: Colors.bg, alignItems:'center', justifyContent:'center', gap: 10 },
  icon: { fontSize: 48 },
  text: { color: Colors.text, fontFamily:'monospace', fontSize:15, fontWeight:'700' },
  sub:  { color: Colors.textSub, fontFamily:'monospace', fontSize:11 },
  btn:  { marginTop: 8, paddingVertical: 12, paddingHorizontal: 28, backgroundColor: 'rgba(59,139,255,0.15)', borderRadius: Radius.md, borderWidth:1, borderColor:'rgba(59,139,255,0.3)' },
  btnText: { color: Colors.blue, fontFamily:'monospace', fontSize:13, fontWeight:'700' },
});
