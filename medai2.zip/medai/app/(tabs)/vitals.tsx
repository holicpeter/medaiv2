import { useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, RefreshControl, ActivityIndicator,
} from 'react-native';
import { useHealthStore } from '@/store/health.store';
import { useHealthSync } from '@/hooks/useHealthSync';
import { Colors, Spacing, Radius } from '@/constants/theme';
import type { Observation } from '@/models/health.types';

const FLAG_COLOR: Record<string, string> = {
  N: Colors.green, H: Colors.orange, L: Colors.orange,
  HH: Colors.red,  LL: Colors.red,
};

// LOINC display order for the vitals screen
const DISPLAY_ORDER = [
  '8867-4',   // Heart Rate
  '8480-6',   // Systolic BP
  '8462-4',   // Diastolic BP
  '2339-0',   // Blood Glucose
  '2708-6',   // SpO2
  '8310-5',   // Body Temperature
  '29463-7',  // Weight
  '39156-5',  // BMI
  '55423-8',  // Steps
  '41981-2',  // Active Energy
  '9279-1',   // Respiratory Rate
  '8867-4',   // (already listed — deduplicated below)
  '40443-4',  // Resting HR
  '80404-7',  // HRV
];

function latestPerLoinc(obs: Observation[]): Observation[] {
  const seen = new Set<string>();
  const result: Observation[] = [];
  // Sort newest first
  const sorted = [...obs].sort((a, b) =>
    new Date(b.effectiveDatetime).getTime() - new Date(a.effectiveDatetime).getTime()
  );
  for (const o of sorted) {
    if (!seen.has(o.loincCode)) {
      seen.add(o.loincCode);
      result.push(o);
    }
  }
  // Sort by display order
  return result.sort((a, b) => {
    const ia = DISPLAY_ORDER.indexOf(a.loincCode);
    const ib = DISPLAY_ORDER.indexOf(b.loincCode);
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
  });
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)   return 'just now';
  if (m < 60)  return `${m}m ago`;
  if (m < 1440)return `${Math.floor(m / 60)}h ago`;
  return `${Math.floor(m / 1440)}d ago`;
}

export default function VitalsTab() {
  const observations = useHealthStore(s => s.observations);
  const syncing      = useHealthStore(s => s.syncing);
  const { sync }     = useHealthSync();

  const latest = latestPerLoinc(observations);

  const onRefresh = useCallback(() => { sync(true); }, [sync]);

  if (syncing && latest.length === 0) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={Colors.blue} size="large" />
        <Text style={styles.syncingText}>Syncing Apple Health...</Text>
      </View>
    );
  }

  if (latest.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.emptyIcon}>📡</Text>
        <Text style={styles.emptyTitle}>No vitals yet</Text>
        <Text style={styles.emptySub}>Connect Apple Health in Settings{'\n'}or pull down to sync.</Text>
        <TouchableOpacity style={styles.syncBtn} onPress={() => sync(true)}>
          <Text style={styles.syncBtnText}>Sync now</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={styles.scroll}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={syncing}
          onRefresh={onRefresh}
          tintColor={Colors.blue}
        />
      }
    >
      <View style={styles.header}>
        <Text style={styles.title}>Vitals</Text>
        <Text style={styles.count}>{latest.length} metrics</Text>
      </View>

      {latest.map((obs, i) => {
        const fc = FLAG_COLOR[obs.flag] ?? Colors.green;
        const hasRef = obs.refLow !== null || obs.refHigh !== null;
        const pct = obs.refHigh && obs.refLow
          ? Math.min(Math.max((obs.valueQuantity - obs.refLow!) / (obs.refHigh - obs.refLow!), 0), 1.2)
          : null;

        return (
          <View key={obs.id ?? i} style={styles.card}>
            {/* Top row */}
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={styles.metricName}>{obs.displayName}</Text>
                <Text style={styles.loincText}>LOINC {obs.loincCode} · {timeAgo(obs.effectiveDatetime)}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={[styles.value, { color: fc }]}>
                  {obs.valueQuantity % 1 === 0
                    ? obs.valueQuantity
                    : obs.valueQuantity.toFixed(1)}
                  <Text style={styles.unit}> {obs.unit}</Text>
                </Text>
                <View style={styles.flagRow}>
                  <View style={[styles.flagDot, { backgroundColor: fc }]} />
                  <Text style={[styles.flagText, { color: fc }]}>
                    {obs.flag === 'N' ? 'Normal' : obs.flag === 'H' || obs.flag === 'HH' ? 'High' : 'Low'}
                  </Text>
                </View>
              </View>
            </View>

            {/* Reference range bar */}
            {pct !== null && (
              <View style={{ marginTop: 10 }}>
                <View style={styles.refLabels}>
                  <Text style={styles.refText}>
                    {obs.refLow != null ? `Low ${obs.refLow}` : ''}
                  </Text>
                  <Text style={styles.refText}>Optimal range</Text>
                  <Text style={styles.refText}>
                    {obs.refHigh != null ? `High ${obs.refHigh}` : ''}
                  </Text>
                </View>
                <View style={styles.refBar}>
                  <View style={[styles.refNormal, {
                    left: '0%', right: '0%', position: 'absolute',
                    backgroundColor: 'rgba(34,211,160,0.1)', borderRadius: 2
                  }]} />
                  <View style={[styles.refIndicator, {
                    left: `${Math.min(pct * 100, 95)}%`,
                    backgroundColor: fc,
                    shadowColor: fc,
                  }]} />
                </View>
              </View>
            )}

            {/* Source badge */}
            <Text style={styles.sourceText}>
              {obs.source === 'apple_healthkit' ? '⌚ Apple Health' :
               obs.source === 'ocr_import' ? '📄 OCR import' : '✏️ Manual'}
            </Text>
          </View>
        );
      })}

      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          ⚕️ Health indicators only. Not a medical diagnosis.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:           { flex: 1, backgroundColor: Colors.bg },
  scroll:         { padding: Spacing.lg, paddingTop: 56, paddingBottom: 100 },
  center:         { flex: 1, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  syncingText:    { color: Colors.textSub, fontSize: 12, marginTop: 12, fontFamily: 'monospace' },
  emptyIcon:      { fontSize: 44, marginBottom: 12 },
  emptyTitle:     { fontSize: 15, fontWeight: '700', color: Colors.text, marginBottom: 6 },
  emptySub:       { fontSize: 12, color: Colors.textSub, textAlign: 'center', lineHeight: 18, marginBottom: 20 },
  syncBtn:        { paddingVertical: 11, paddingHorizontal: 28, backgroundColor: 'rgba(59,139,255,0.15)', borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(59,139,255,0.3)' },
  syncBtnText:    { color: Colors.blue, fontFamily: 'monospace', fontSize: 13, fontWeight: '700' },
  header:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: Spacing.md },
  title:          { fontSize: 22, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  count:          { fontSize: 10, color: Colors.textSub, fontFamily: 'monospace' },
  card:           { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.sm },
  row:            { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  metricName:     { fontSize: 13, fontWeight: '700', color: Colors.text, marginBottom: 2 },
  loincText:      { fontSize: 9, color: Colors.textSub, fontFamily: 'monospace' },
  value:          { fontSize: 22, fontWeight: '700', letterSpacing: -0.5 },
  unit:           { fontSize: 11, color: Colors.textSub, fontWeight: '400' },
  flagRow:        { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  flagDot:        { width: 6, height: 6, borderRadius: 3 },
  flagText:       { fontSize: 9, fontWeight: '700', fontFamily: 'monospace' },
  refLabels:      { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3 },
  refText:        { fontSize: 8, color: Colors.textMuted, fontFamily: 'monospace' },
  refBar:         { height: 5, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 3, overflow: 'visible', position: 'relative' },
  refNormal:      { top: 0, bottom: 0 },
  refIndicator:   { position: 'absolute', top: -2, width: 3, height: 9, borderRadius: 2, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 4 },
  sourceText:     { fontSize: 9, color: Colors.textMuted, marginTop: 8, fontFamily: 'monospace' },
  disclaimer:     { marginTop: 8, padding: 11, backgroundColor: 'rgba(255,61,92,0.05)', borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(255,61,92,0.15)' },
  disclaimerText: { fontSize: 10, color: Colors.textSub, lineHeight: 16 },
});
