/**
 * Insights Tab — calls Claude clinical-reasoner API
 * Generates: trend_alert, recommendation, weekly_summary
 * All outputs include mandatory safety disclaimer (CLAUDE.md rules)
 */
import { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl,
} from 'react-native';
import { useHealthStore } from '@/store/health.store';
import { Colors, Spacing, Radius } from '@/constants/theme';
import { saveInsight } from '@/services/supabase';
import type { AIInsight, ActionItem } from '@/models/health.types';

// ── Safety disclaimer — hardcoded, never omitted ──────────
const DISCLAIMER = 'Health risk indicator only. Not a medical diagnosis. Consult your physician.';

// ── System prompt (mirrors clinical-reasoner.service.ts) ──
const SYSTEM_PROMPT = `You are the clinical-reasoner AI engine for MedAI, a Personal Health Intelligence Platform operating under EU medical AI regulations.

MANDATORY SAFETY RULES:
1. Frame ALL outputs as "risk indicators" — NEVER "diagnosis", "you have", "you are suffering from"
2. ALWAYS include disclaimer: "Health risk indicator only. Not a medical diagnosis."
3. ALWAYS include confidence: low / medium / high
4. If any metric has HH/LL flag or probability > 0.75 → add consult_doctor action with urgency: immediate
5. Never recommend specific drug names or dosage changes
6. Return ONLY valid JSON — no markdown, no explanation`;

// ── Build context string from observations ────────────────
function buildPatientContext(
  patient: ReturnType<typeof useHealthStore.getState>['patient'],
  observations: ReturnType<typeof useHealthStore.getState>['observations']
): string {
  if (!patient) return '';

  const age = patient.dateOfBirth
    ? Math.floor((Date.now() - new Date(patient.dateOfBirth).getTime()) / 31557600000)
    : '?';

  const bmi = patient.heightCm && patient.weightKg
    ? (patient.weightKg / Math.pow(patient.heightCm / 100, 2)).toFixed(1)
    : '?';

  // Latest per LOINC
  const seen = new Set<string>();
  const latest = observations
    .sort((a, b) => new Date(b.effectiveDatetime).getTime() - new Date(a.effectiveDatetime).getTime())
    .filter(o => { if (seen.has(o.loincCode)) return false; seen.add(o.loincCode); return true; });

  const obsText = latest.slice(0, 10).map(o =>
    `- ${o.displayName} (LOINC ${o.loincCode}): ${o.valueQuantity} ${o.unit} [flag: ${o.flag}]`
  ).join('\n') || 'No biometric data yet';

  return `Patient: ${age}yo ${patient.sex ?? 'unknown'}, BMI ${bmi}, smoking: ${patient.smokingStatus}, activity: ${patient.activityLevel}

Biometrics (latest per metric):
${obsText}`;
}

// ── Prompts ───────────────────────────────────────────────
const PROMPTS: Record<string, (ctx: string) => string> = {
  trend_alert: ctx => `${ctx}

Identify the most concerning biometric trend and generate a clear alert. Return JSON:
{
  "insightType": "trend_alert",
  "priority": "critical"|"warning"|"info",
  "title": "string (max 60 chars)",
  "body": "2-3 sentences explaining what is changing and why it matters",
  "actionItems": [{"action":"string","category":"diet"|"exercise"|"monitoring"|"consult_doctor"|"lifestyle","urgency":"immediate"|"this_week"|"this_month"|"ongoing","evidenceNote":"string"}],
  "confidence": "low"|"medium"|"high",
  "disclaimer": "${DISCLAIMER}"
}`,

  recommendation: ctx => `${ctx}

Generate 3-4 specific lifestyle recommendations based on the biometric profile. Do NOT recommend medications. Return JSON:
{
  "insightType": "recommendation",
  "priority": "info"|"warning",
  "title": "string",
  "body": "2-3 sentence overview",
  "actionItems": [{"action":"string","category":"diet"|"exercise"|"lifestyle"|"monitoring","urgency":"this_week"|"this_month"|"ongoing","evidenceNote":"string"}],
  "confidence": "medium"|"high",
  "disclaimer": "${DISCLAIMER}"
}`,

  weekly_summary: ctx => `${ctx}

Generate an encouraging weekly health summary. Tone: supportive, not alarming. Return JSON:
{
  "insightType": "weekly_summary",
  "priority": "positive"|"info"|"warning",
  "title": "string",
  "body": "3-4 sentences: what is good, what to watch, one key focus",
  "actionItems": [{"action":"string","category":"lifestyle"|"exercise"|"diet","urgency":"this_week"}],
  "confidence": "medium",
  "disclaimer": "${DISCLAIMER}"
}`,
};

// ── Priority config ───────────────────────────────────────
const PRIORITY_CFG = {
  critical: { color: Colors.red,    icon: '🔴' },
  warning:  { color: Colors.orange, icon: '🟠' },
  info:     { color: Colors.blue,   icon: '🔵' },
  positive: { color: Colors.green,  icon: '🟢' },
};

const URGENCY_COLOR: Record<string, string> = {
  immediate:   Colors.red,
  this_week:   Colors.orange,
  this_month:  Colors.blue,
  ongoing:     Colors.textSub,
};

const CAT_ICON: Record<string, string> = {
  diet: '🥗', exercise: '🏃', monitoring: '📊',
  consult_doctor: '👨‍⚕️', lifestyle: '🌙',
};

// ── Insight card ──────────────────────────────────────────
function InsightCard({
  insight, onDismiss,
}: {
  insight: AIInsight;
  onDismiss: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const pc = PRIORITY_CFG[insight.priority] ?? PRIORITY_CFG.info;

  return (
    <View style={[styles.card, { borderLeftColor: pc.color }]}>
      <TouchableOpacity onPress={() => setExpanded(e => !e)} activeOpacity={0.8}>
        <View style={styles.cardHeader}>
          <View style={styles.cardHeaderLeft}>
            <View style={[styles.badge, { borderColor: `${pc.color}40`, backgroundColor: `${pc.color}12` }]}>
              <Text style={[styles.badgeText, { color: pc.color }]}>
                {pc.icon} {insight.priority}
              </Text>
            </View>
            <Text style={styles.cardType}>{insight.insightType.replace('_', ' ')}</Text>
          </View>
          <Text style={[styles.chevron, { transform: [{ rotate: expanded ? '180deg' : '0deg' }] }]}>▾</Text>
        </View>
        <Text style={styles.cardTitle}>{insight.title}</Text>
      </TouchableOpacity>

      {expanded && (
        <>
          <Text style={styles.cardBody}>{insight.body}</Text>

          {insight.actionItems.length > 0 && (
            <View style={styles.actions}>
              <Text style={styles.actionsLabel}>Actions</Text>
              {insight.actionItems.map((a: ActionItem, i: number) => (
                <View key={i} style={styles.actionRow}>
                  <Text style={styles.actionIcon}>{CAT_ICON[a.category] ?? '•'}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.actionText}>{a.action}</Text>
                    <View style={styles.actionMeta}>
                      <Text style={styles.actionCat}>{a.category}</Text>
                      <Text style={[styles.actionUrgency, { color: URGENCY_COLOR[a.urgency] ?? Colors.textSub }]}>
                        · {a.urgency.replace('_', ' ')}
                      </Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          )}

          <View style={styles.disclaimerBox}>
            <Text style={styles.disclaimerText}>⚕️ {insight.disclaimer}</Text>
          </View>

          <TouchableOpacity onPress={() => onDismiss(insight.id)} style={styles.dismissBtn}>
            <Text style={styles.dismissText}>Dismiss</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────
export default function InsightsTab() {
  const patient      = useHealthStore(s => s.patient);
  const observations = useHealthStore(s => s.observations);
  const insights     = useHealthStore(s => s.insights);
  const setInsights  = useHealthStore(s => s.setInsights);
  const dismissFn    = useHealthStore(s => s.dismissInsight);
  const analysing    = useHealthStore(s => s.analysing);
  const setAnalysing = useHealthStore(s => s.setAnalysing);

  const [activeType, setActiveType] = useState<string>('recommendation');
  const [error, setError]           = useState<string | null>(null);

  const activeInsights = insights.filter(i => !i.dismissedAt);

  const runAnalysis = useCallback(async () => {
    if (!patient?.id || observations.length === 0) return;

    setAnalysing(true);
    setError(null);

    try {
      const ctx = buildPatientContext(patient, observations);
      const prompt = PROMPTS[activeType]?.(ctx);
      if (!prompt) return;

      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model:      'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system:     SYSTEM_PROMPT,
          messages:   [{ role: 'user', content: prompt }],
        }),
      });

      if (!res.ok) throw new Error(`API error ${res.status}`);
      const data = await res.json();
      const raw  = data.content?.[0]?.text ?? '';
      const clean = raw.replace(/```json\n?|```\n?/g, '').trim();
      const parsed = JSON.parse(clean);

      const insight: AIInsight = {
        id:           `ins-${Date.now()}`,
        patientId:    patient.id,
        insightType:  parsed.insightType ?? activeType as any,
        priority:     parsed.priority ?? 'info',
        title:        parsed.title ?? 'Health insight',
        body:         parsed.body ?? '',
        actionItems:  parsed.actionItems ?? [],
        confidence:   parsed.confidence ?? 'medium',
        disclaimer:   parsed.disclaimer ?? DISCLAIMER,
        createdAt:    new Date().toISOString(),
      };

      // Save to Supabase + Zustand
      try { await saveInsight(insight); } catch { /* non-fatal */ }
      setInsights([insight, ...insights]);

    } catch (e: any) {
      setError(e.message ?? 'Analysis failed');
    } finally {
      setAnalysing(false);
    }
  }, [patient, observations, activeType, insights]);

  const TYPES = [
    { id: 'trend_alert',    label: 'Trend Alert',    icon: '📈' },
    { id: 'recommendation', label: 'Recommendations', icon: '💡' },
    { id: 'weekly_summary', label: 'Weekly',          icon: '📅' },
  ];

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={styles.scroll}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={analysing} onRefresh={runAnalysis} tintColor={Colors.blue} />
      }
    >
      <View style={styles.header}>
        <Text style={styles.title}>AI Insights</Text>
        <Text style={styles.model}>claude-sonnet-4 · clinical-reasoner-v1.2</Text>
      </View>

      {/* Type selector */}
      <View style={styles.typeRow}>
        {TYPES.map(t => (
          <TouchableOpacity
            key={t.id}
            style={[styles.typeBtn, activeType === t.id && styles.typeBtnActive]}
            onPress={() => setActiveType(t.id)}
          >
            <Text style={styles.typeIcon}>{t.icon}</Text>
            <Text style={[styles.typeLabel, activeType === t.id && styles.typeLabelActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* No data state */}
      {observations.length === 0 && (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyIcon}>📡</Text>
          <Text style={styles.emptyTitle}>Sync health data first</Text>
          <Text style={styles.emptySub}>Go to Overview and sync Apple Health to enable AI analysis.</Text>
        </View>
      )}

      {/* Generate button */}
      {observations.length > 0 && (
        <TouchableOpacity
          style={[styles.generateBtn, analysing && styles.generateBtnDisabled]}
          disabled={analysing}
          onPress={runAnalysis}
        >
          {analysing ? (
            <View style={styles.generateRow}>
              <ActivityIndicator color="#fff" size="small" />
              <Text style={styles.generateText}>Analysing with Claude...</Text>
            </View>
          ) : (
            <Text style={styles.generateText}>▶ Generate {TYPES.find(t => t.id === activeType)?.label}</Text>
          )}
        </TouchableOpacity>
      )}

      {/* Error */}
      {error && (
        <View style={styles.errorCard}>
          <Text style={styles.errorText}>⚠️ {error}</Text>
        </View>
      )}

      {/* Insight cards */}
      {activeInsights.length > 0 && (
        <>
          <Text style={styles.sectionLabel}>
            {activeInsights.length} active insight{activeInsights.length > 1 ? 's' : ''}
          </Text>
          {activeInsights.map(ins => (
            <InsightCard key={ins.id} insight={ins} onDismiss={dismissFn} />
          ))}
        </>
      )}

      {activeInsights.length === 0 && observations.length > 0 && !analysing && (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyIcon}>🧠</Text>
          <Text style={styles.emptyTitle}>No insights yet</Text>
          <Text style={styles.emptySub}>Tap Generate to run your first AI health analysis.</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:               { flex: 1, backgroundColor: Colors.bg },
  scroll:             { padding: Spacing.lg, paddingTop: 56, paddingBottom: 100 },
  header:             { marginBottom: Spacing.lg },
  title:              { fontSize: 22, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  model:              { fontSize: 9, color: Colors.textSub, fontFamily: 'monospace', marginTop: 2 },
  typeRow:            { flexDirection: 'row', gap: 6, marginBottom: Spacing.md },
  typeBtn:            { flex: 1, padding: 10, borderRadius: Radius.sm, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', gap: 3 },
  typeBtnActive:      { borderColor: Colors.blue, backgroundColor: 'rgba(59,139,255,0.1)' },
  typeIcon:           { fontSize: 16 },
  typeLabel:          { fontSize: 9, color: Colors.textSub, fontFamily: 'monospace', fontWeight: '700', letterSpacing: 0.3, textAlign: 'center' },
  typeLabelActive:    { color: Colors.blue },
  generateBtn:        { backgroundColor: Colors.blue, borderRadius: Radius.md, padding: 15, alignItems: 'center', marginBottom: Spacing.md },
  generateBtnDisabled:{ opacity: 0.5 },
  generateRow:        { flexDirection: 'row', alignItems: 'center', gap: 10 },
  generateText:       { color: '#fff', fontSize: 13, fontWeight: '700', fontFamily: 'monospace' },
  errorCard:          { backgroundColor: 'rgba(255,61,92,0.08)', borderRadius: Radius.md, padding: 12, borderWidth: 1, borderColor: 'rgba(255,61,92,0.25)', marginBottom: Spacing.sm },
  errorText:          { fontSize: 11, color: Colors.red },
  sectionLabel:       { fontSize: 9, color: Colors.textSub, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: Spacing.sm },
  card:               { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: Colors.border, borderLeftWidth: 3, marginBottom: Spacing.sm },
  cardHeader:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  cardHeaderLeft:     { flexDirection: 'row', alignItems: 'center', gap: 8 },
  badge:              { paddingVertical: 2, paddingHorizontal: 7, borderRadius: 4, borderWidth: 1 },
  badgeText:          { fontSize: 9, fontWeight: '700', letterSpacing: 0.5, textTransform: 'uppercase' },
  cardType:           { fontSize: 9, color: Colors.textSub },
  chevron:            { color: Colors.textSub, fontSize: 12 },
  cardTitle:          { fontSize: 13, fontWeight: '700', color: Colors.text, lineHeight: 18 },
  cardBody:           { fontSize: 12, color: Colors.textSub, lineHeight: 18, marginTop: 8, marginBottom: 12 },
  actions:            { borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: 12, marginBottom: 10 },
  actionsLabel:       { fontSize: 9, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8 },
  actionRow:          { flexDirection: 'row', gap: 10, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.04)' },
  actionIcon:         { fontSize: 18, width: 24 },
  actionText:         { fontSize: 12, color: Colors.text, lineHeight: 17 },
  actionMeta:         { flexDirection: 'row', marginTop: 2 },
  actionCat:          { fontSize: 9, color: Colors.textSub },
  actionUrgency:      { fontSize: 9, fontWeight: '700' },
  disclaimerBox:      { backgroundColor: 'rgba(255,61,92,0.05)', borderRadius: 7, padding: 9, borderWidth: 1, borderColor: 'rgba(255,61,92,0.15)', marginBottom: 8 },
  disclaimerText:     { fontSize: 9, color: Colors.textSub, lineHeight: 15 },
  dismissBtn:         { alignItems: 'flex-end' },
  dismissText:        { fontSize: 10, color: Colors.textSub, fontFamily: 'monospace' },
  emptyCard:          { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.xl, alignItems: 'center', borderWidth: 1, borderColor: Colors.border, borderStyle: 'dashed' },
  emptyIcon:          { fontSize: 36, marginBottom: 10 },
  emptyTitle:         { fontSize: 14, fontWeight: '700', color: Colors.text, marginBottom: 4 },
  emptySub:           { fontSize: 12, color: Colors.textSub, textAlign: 'center', lineHeight: 18 },
});
