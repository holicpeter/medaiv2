import { Tabs } from 'expo-router';
import { Colors } from '@/constants/theme';

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: Colors.bgCard,
          borderTopColor: Colors.border,
          borderTopWidth: 1,
          height: 72,
          paddingBottom: 16,
        },
        tabBarActiveTintColor:   Colors.blue,
        tabBarInactiveTintColor: Colors.textSub,
        tabBarLabelStyle: {
          fontSize: 9,
          fontFamily: 'monospace',
          letterSpacing: 0.5,
          textTransform: 'uppercase',
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen name="index"    options={{ title: 'Overview',  tabBarIcon: ({ color }) => <TabIcon glyph="⬡" color={color} /> }} />
      <Tabs.Screen name="vitals"   options={{ title: 'Vitals',    tabBarIcon: ({ color }) => <TabIcon glyph="♥" color={color} /> }} />
      <Tabs.Screen name="scan"     options={{ title: 'Scan',      tabBarIcon: ({ color }) => <TabIcon glyph="◎" color={color} /> }} />
      <Tabs.Screen name="insights" options={{ title: 'Insights',  tabBarIcon: ({ color }) => <TabIcon glyph="◈" color={color} /> }} />
    </Tabs>
  );
}

function TabIcon({ glyph, color }: { glyph: string; color: string }) {
  const { Text } = require('react-native');
  return <Text style={{ fontSize: 18, color }}>{glyph}</Text>;
}
