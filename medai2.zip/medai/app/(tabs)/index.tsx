import { useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, RefreshControl, ActivityIndicator,
} from 'react-native';
import { useHealthStore } from '@/store/health.store';
import { useHealthSync } from '@/hooks/useHealthSync';
import { Colors, Spacing, Radius, Risk } from '@/constants/theme';

const FLAG_COLOR: Record<string, string> = {
  N: Colors.green, H: Colors.orange, L: Colors.orange,
  HH: Colors.red,  LL: Colors.red,
};

// Quick vitals to show on overview (LOINC codes)
const QUICK_VITALS = [
  { loinc: '8867-4',  label: 'Heart Rate' },
  { loinc: '8480-6',  label: 'Systolic BP' },
  { loinc: '2339-0',  label: 'Glucose' },
  { loinc: '2708-6',  label: 'SpO₂' },
];

export default function OverviewTab() {
  const patient      = useHealthStore(s => s.patient);
  const observations = useHealthStore(s => s.observations);
  const riskScores   = useHealthStore(s => s.riskScores);
  const insights     = useHealthStore(s => s.insights);
  const syncing      = useHealthStore(s => s.syncing);
  const lastSynced   = useHealthStore(s => s.lastSyncedAt);
  const { sync }     = useHealthSync();

  if (!patient) return null;

  const topRisk = [...riskScores].sort((a, b) => b.probability - a.probability)[0];

  // Latest obs per loinc
  const latestByLoinc = (loinc: string) =>
    [...observations]
      .filter(o => o.loincCode === loinc)
      .sort((a, b) => new Date(b.effectiveDatetime).getTime() - new Date(a.effectiveDatetime).getTime())
      [0] ?? null;

  // Flagged observations
  const flagged = observations.filter(
    o => (o.flag === 'H' || o.flag === 'HH' || o.flag === 'L' || o.flag === 'LL') &&
         observations.filter(x => x.loincCode === o.loincCode).indexOf(o) === 0
  );

  function timeAgo(iso: string) {
    const m = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return `${m}m ago`;
    if (m < 1440) return `${Math.floor(m/60)}h ago`;
    return `${Math.floor(m/1440)}d ago`;
  }

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={styles.scroll}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={syncing} onRefresh={() => sync(true)} tintColor={Colors.blue} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good morning,</Text>
          <Text style={styles.name}>{patient.firstName ?? 'User'}</Text>
        </View>
        <View style={styles.syncRow}>
          {syncing
            ? <ActivityIndicator size="small" color={Colors.green} />
            : <View style={styles.syncDot} />
          }
          <Text style={styles.syncText}>
            {syncing ? 'Syncing...' : lastSynced ? timeAgo(lastSynced) : 'Not synced'}
          </Text>
        </View>
      </View>

      {/* Flagged alerts */}
      {flagged.length > 0 && (
        <View style={[styles.card, styles.alertCard]}>
          <Text style={styles.alertTitle}>⚠️ {flagged.length} metric{flagged.length > 1 ? 's' : ''} need attention</Text>
          {flagged.slice(0, 3).map((o, i) => (
            <Text key={i} style={styles.alertItem}>
              · {o.displayName}: {o.valueQuantity.toFixed(1)} {o.unit}
              {' '}
              <Text style={{ color: FLAG_COLOR[o.flag] }}>{o.flag === 'H' || o.flag === 'HH' ? '↑' : '↓'} {o.flag}</Text>
            </Text>
          ))}
        </View>
      )}

      {/* Quick vitals grid */}
      {observations.length > 0 && (
        <>
          <Text style={styles.sectionLabel}>Latest readings</Text>
          <View style={styles.grid}>
            {QUICK_VITALS.map(({ loinc, label }) => {
              const obs = latestByLoinc(loinc);
              if (!obs) return null;
              const fc = FLAG_COLOR[obs.flag] ?? Colors.green;
              return (
                <View key={loinc} style={styles.miniCard}>
                  <Text style={styles.miniLabel} numberOfLines={1}>{label}</Text>
                  <Text style={[styles.miniValue, { color: fc }]}>
                    {obs.valueQuantity % 1 === 0 ? obs.valueQuantity : obs.valueQuantity.toFixed(1)}
                    <Text style={styles.miniUnit}> {obs.unit}</Text>
                  </Text>
                  <View style={[styles.miniFlag, { backgroundColor: `${fc}20` }]}>
                    <Text style={[styles.miniFlagText, { color: fc }]}>
                      {obs.flag === 'N' ? '✓ OK' : obs.flag}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        </>
      )}

      {/* Risk scores */}
      {riskScores.length > 0 && (
        <>
          <Text style={styles.sectionLabel}>Chronic disease risk</Text>
          {riskScores.map((rs, i) => (
            <View key={i} style={styles.card}>
              <View style={styles.riskRow}>
                <Text style={styles.riskName}>{rs.conditionDisplay}</Text>
                <Text style={[styles.riskPct, { color: Risk[rs.riskTier] }]}>
                  {(rs.probability * 100).toFixed(0)}%
                </Text>
              </View>
              <View style={styles.riskBar}>
                <View style={[styles.riskFill, {
                  width: `${rs.probability * 100}%` as any,
                  backgroundColor: Risk[rs.riskTier],
                }]} />
              </View>
              <Text style={[styles.riskTier, { color: Risk[rs.riskTier] }]}>
                {rs.riskTier.toUpperCase()} · {rs.horizonMonths}mo outlook
              </Text>
            </View>
          ))}
        </>
      )}

      {/* Active insights */}
      {insights.filter(i => !i.dismissedAt).slice(0, 2).map((ins, i) => {
        const pc = ins.priority === 'critical' ? Colors.red
                 : ins.priority === 'warning'  ? Colors.orange
                 : ins.priority === 'positive' ? Colors.green
                 : Colors.blue;
        return (
          <View key={i} style={[styles.insightCard, { borderLeftColor: pc }]}>
            <Text style={styles.insightTitle}>{ins.title}</Text>
            <Text style={styles.insightBody} numberOfLines={2}>{ins.body}</Text>
          </View>
        );
      })}

      {/* Empty state */}
      {observations.length === 0 && !syncing && (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyIcon}>📡</Text>
          <Text style={styles.emptyTitle}>No data yet</Text>
          <Text style={styles.emptySub}>
            Connect Apple Health or scan a lab result to get started.
          </Text>
          <TouchableOpacity style={styles.syncBtn} onPress={() => sync(true)}>
            <Text style={styles.syncBtnText}>Sync Apple Health</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Disclaimer */}
      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          ⚕️ MedAI provides health risk indicators, not medical diagnoses. Always consult your physician.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:           { flex: 1, backgroundColor: Colors.bg },
  scroll:         { padding: Spacing.lg, paddingTop: 56, paddingBottom: 100 },
  header:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.lg },
  greeting:       { fontSize: 12, color: Colors.textSub },
  name:           { fontSize: 22, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  syncRow:        { flexDirection: 'row', alignItems: 'center', gap: 5 },
  syncDot:        { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.green },
  syncText:       { fontSize: 9, color: Colors.green, fontFamily: 'monospace' },
  card:           { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.sm },
  alertCard:      { borderColor: 'rgba(255,123,59,0.3)', backgroundColor: 'rgba(255,123,59,0.06)' },
  alertTitle:     { fontSize: 12, fontWeight: '700', color: Colors.orange, marginBottom: 8 },
  alertItem:      { fontSize: 11, color: Colors.textSub, paddingVertical: 2 },
  sectionLabel:   { fontSize: 9, color: Colors.textSub, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: Spacing.sm, marginTop: Spacing.sm },
  grid:           { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: Spacing.sm },
  miniCard:       { flex: 1, minWidth: '45%', backgroundColor: Colors.bgCard, borderRadius: Radius.md, padding: 12, borderWidth: 1, borderColor: Colors.border },
  miniLabel:      { fontSize: 9, color: Colors.textSub, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 },
  miniValue:      { fontSize: 20, fontWeight: '700', letterSpacing: -0.5 },
  miniUnit:       { fontSize: 9, fontWeight: '400', color: Colors.textSub },
  miniFlag:       { alignSelf: 'flex-start', paddingVertical: 2, paddingHorizontal: 6, borderRadius: 4, marginTop: 6 },
  miniFlagText:   { fontSize: 9, fontWeight: '700', fontFamily: 'monospace' },
  riskRow:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  riskName:       { fontSize: 13, fontWeight: '700', color: Colors.text },
  riskPct:        { fontSize: 18, fontWeight: '700' },
  riskBar:        { height: 4, backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 2, overflow: 'hidden', marginBottom: 6 },
  riskFill:       { height: '100%', borderRadius: 2 },
  riskTier:       { fontSize: 9, fontWeight: '700', letterSpacing: 1, fontFamily: 'monospace' },
  insightCard:    { backgroundColor: Colors.bgCard, borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: Colors.border, borderLeftWidth: 3, marginBottom: Spacing.sm },
  insightTitle:   { fontSize: 12, fontWeight: '700', color: Colors.text, marginBottom: 4 },
  insightBody:    { fontSize: 11, color: Colors.textSub, lineHeight: 17 },
  emptyCard:      { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.xl, alignItems: 'center', borderWidth: 1, borderColor: Colors.border, borderStyle: 'dashed' },
  emptyIcon:      { fontSize: 36, marginBottom: 10 },
  emptyTitle:     { fontSize: 15, fontWeight: '700', color: Colors.text, marginBottom: 4 },
  emptySub:       { fontSize: 12, color: Colors.textSub, textAlign: 'center', lineHeight: 18, marginBottom: 16 },
  syncBtn:        { paddingVertical: 11, paddingHorizontal: 24, backgroundColor: 'rgba(59,139,255,0.15)', borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(59,139,255,0.3)' },
  syncBtnText:    { color: Colors.blue, fontSize: 13, fontWeight: '700', fontFamily: 'monospace' },
  disclaimer:     { marginTop: 8, padding: 11, backgroundColor: 'rgba(255,61,92,0.05)', borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(255,61,92,0.15)' },
  disclaimerText: { fontSize: 10, color: Colors.textSub, lineHeight: 16 },
});
