import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Colors, Spacing, Radius } from '@/constants/theme';

const BLOOD_TYPES = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];

export default function Step2() {
  const params                    = useLocalSearchParams();
  const [heightCm, setHeightCm]   = useState('');
  const [weightKg, setWeightKg]   = useState('');
  const [bloodType, setBloodType] = useState('');

  const canContinue = heightCm.length > 0 && weightKg.length > 0;

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS==='ios'?'padding':undefined}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.progress}>
          {[1,2,3,4].map(i => (
            <View key={i} style={[styles.dot, i <= 2 && styles.dotActive]} />
          ))}
        </View>

        <Text style={styles.eyebrow}>Step 2 of 4</Text>
        <Text style={styles.title}>Body measurements</Text>
        <Text style={styles.sub}>Used to calculate BMI and calibrate risk models.</Text>

        <View style={styles.row}>
          <View style={styles.half}>
            <Text style={styles.label}>Height (cm)</Text>
            <TextInput
              style={styles.input} placeholder="175"
              placeholderTextColor={Colors.textMuted}
              value={heightCm} onChangeText={setHeightCm}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.half}>
            <Text style={styles.label}>Weight (kg)</Text>
            <TextInput
              style={styles.input} placeholder="80"
              placeholderTextColor={Colors.textMuted}
              value={weightKg} onChangeText={setWeightKg}
              keyboardType="decimal-pad"
            />
          </View>
        </View>

        {heightCm && weightKg && (
          <View style={styles.bmiCard}>
            <Text style={styles.bmiLabel}>BMI</Text>
            <Text style={styles.bmiValue}>
              {(parseFloat(weightKg) / Math.pow(parseFloat(heightCm)/100, 2)).toFixed(1)}
            </Text>
          </View>
        )}

        <Text style={styles.label}>Blood type (optional)</Text>
        <View style={styles.chips}>
          {BLOOD_TYPES.map(bt => (
            <TouchableOpacity
              key={bt}
              style={[styles.chip, bloodType===bt && styles.chipActive]}
              onPress={() => setBloodType(bt === bloodType ? '' : bt)}
            >
              <Text style={[styles.chipText, bloodType===bt && styles.chipTextActive]}>{bt}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[styles.btn, !canContinue && styles.btnDisabled]}
          disabled={!canContinue}
          onPress={() => router.push({
            pathname: '/onboarding/step3',
            params: { ...params, heightCm, weightKg, bloodType },
          })}
        >
          <Text style={styles.btnText}>Continue →</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.back} onPress={() => router.back()}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root:          { flex: 1, backgroundColor: Colors.bg },
  scroll:        { padding: Spacing.lg, paddingTop: 56, paddingBottom: 40 },
  progress:      { flexDirection: 'row', gap: 6, marginBottom: Spacing.lg },
  dot:           { flex: 1, height: 3, borderRadius: 2, backgroundColor: Colors.bgLift },
  dotActive:     { backgroundColor: Colors.blue },
  eyebrow:       { fontSize: 10, color: Colors.textSub, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 8, fontFamily: 'monospace' },
  title:         { fontSize: 26, fontWeight: '700', color: Colors.text, marginBottom: 8, letterSpacing: -0.5 },
  sub:           { fontSize: 13, color: Colors.textSub, lineHeight: 20, marginBottom: Spacing.xl },
  row:           { flexDirection: 'row', gap: Spacing.sm },
  half:          { flex: 1 },
  label:         { fontSize: 11, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8, marginTop: Spacing.md },
  input:         { backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, fontSize: 15, color: Colors.text, fontFamily: 'monospace' },
  bmiCard:       { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(59,139,255,0.08)', borderRadius: Radius.md, padding: 12, marginTop: Spacing.sm, borderWidth: 1, borderColor: 'rgba(59,139,255,0.2)' },
  bmiLabel:      { fontSize: 10, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', fontFamily: 'monospace' },
  bmiValue:      { fontSize: 22, fontWeight: '700', color: Colors.blue, fontFamily: 'monospace' },
  chips:         { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip:          { paddingVertical: 9, paddingHorizontal: 14, borderRadius: Radius.sm, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border },
  chipActive:    { borderColor: Colors.blue, backgroundColor: 'rgba(59,139,255,0.12)' },
  chipText:      { fontSize: 13, color: Colors.textSub, fontFamily: 'monospace' },
  chipTextActive:{ color: Colors.blue, fontWeight: '700' },
  btn:           { marginTop: Spacing.xl, backgroundColor: Colors.blue, borderRadius: Radius.md, padding: 16, alignItems: 'center' },
  btnDisabled:   { opacity: 0.3 },
  btnText:       { color: '#fff', fontSize: 15, fontWeight: '700', fontFamily: 'monospace' },
  back:          { alignItems: 'center', marginTop: Spacing.md },
  backText:      { color: Colors.textSub, fontSize: 12, fontFamily: 'monospace' },
});
