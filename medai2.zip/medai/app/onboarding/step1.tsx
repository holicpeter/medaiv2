import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { router } from 'expo-router';
import { Colors, Spacing, Radius } from '@/constants/theme';

export default function Step1() {
  const [firstName, setFirstName] = useState('');
  const [dob, setDob]             = useState('');
  const [sex, setSex]             = useState<'male'|'female'|'other'|null>(null);

  const canContinue = firstName.trim().length > 0 && dob.length === 10 && sex !== null;

  const formatDob = (text: string) => {
    const digits = text.replace(/\D/g, '').slice(0, 8);
    if (digits.length <= 4) return digits;
    if (digits.length <= 6) return `${digits.slice(0,4)}-${digits.slice(4)}`;
    return `${digits.slice(0,4)}-${digits.slice(4,6)}-${digits.slice(6)}`;
  };

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Progress */}
        <View style={styles.progress}>
          {[1,2,3,4].map(i => (
            <View key={i} style={[styles.dot, i === 1 && styles.dotActive]} />
          ))}
        </View>

        <Text style={styles.eyebrow}>Step 1 of 4</Text>
        <Text style={styles.title}>Tell us about yourself</Text>
        <Text style={styles.sub}>This helps MedAI personalise your health risk profile.</Text>

        {/* First name */}
        <Text style={styles.label}>First name</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Peter"
          placeholderTextColor={Colors.textMuted}
          value={firstName}
          onChangeText={setFirstName}
          autoCapitalize="words"
        />

        {/* Date of birth */}
        <Text style={styles.label}>Date of birth</Text>
        <TextInput
          style={styles.input}
          placeholder="YYYY-MM-DD"
          placeholderTextColor={Colors.textMuted}
          value={dob}
          onChangeText={t => setDob(formatDob(t))}
          keyboardType="numeric"
          maxLength={10}
        />

        {/* Sex */}
        <Text style={styles.label}>Biological sex</Text>
        <View style={styles.chips}>
          {(['male','female','other'] as const).map(s => (
            <TouchableOpacity
              key={s}
              style={[styles.chip, sex === s && styles.chipActive]}
              onPress={() => setSex(s)}
            >
              <Text style={[styles.chipText, sex === s && styles.chipTextActive]}>
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.privacy}>
          🔒 Your data stays on your device and encrypted EU servers. Never sold.
        </Text>

        {/* CTA */}
        <TouchableOpacity
          style={[styles.btn, !canContinue && styles.btnDisabled]}
          disabled={!canContinue}
          onPress={() => router.push({
            pathname: '/onboarding/step2',
            params: { firstName, dob, sex: sex! },
          })}
        >
          <Text style={styles.btnText}>Continue →</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root:          { flex: 1, backgroundColor: Colors.bg },
  scroll:        { padding: Spacing.lg, paddingTop: 56, paddingBottom: 40 },
  progress:      { flexDirection: 'row', gap: 6, marginBottom: Spacing.lg },
  dot:           { flex: 1, height: 3, borderRadius: 2, backgroundColor: Colors.bgLift },
  dotActive:     { backgroundColor: Colors.blue },
  eyebrow:       { fontSize: 10, color: Colors.textSub, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 8, fontFamily: 'monospace' },
  title:         { fontSize: 26, fontWeight: '700', color: Colors.text, marginBottom: 8, letterSpacing: -0.5 },
  sub:           { fontSize: 13, color: Colors.textSub, lineHeight: 20, marginBottom: Spacing.xl },
  label:         { fontSize: 11, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8, marginTop: Spacing.md },
  input:         {
    backgroundColor: Colors.bgCard,
    borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.md, padding: 14,
    fontSize: 15, color: Colors.text, fontFamily: 'monospace',
  },
  chips:         { flexDirection: 'row', gap: 8 },
  chip:          {
    flex: 1, paddingVertical: 12, borderRadius: Radius.md,
    backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center',
  },
  chipActive:    { borderColor: Colors.blue, backgroundColor: 'rgba(59,139,255,0.12)' },
  chipText:      { fontSize: 13, color: Colors.textSub, fontFamily: 'monospace' },
  chipTextActive:{ color: Colors.blue, fontWeight: '700' },
  privacy:       { fontSize: 10, color: Colors.textMuted, marginTop: Spacing.lg, lineHeight: 16 },
  btn:           {
    marginTop: Spacing.xl, backgroundColor: Colors.blue,
    borderRadius: Radius.md, padding: 16, alignItems: 'center',
  },
  btnDisabled:   { opacity: 0.3 },
  btnText:       { color: '#fff', fontSize: 15, fontWeight: '700', fontFamily: 'monospace' },
});
