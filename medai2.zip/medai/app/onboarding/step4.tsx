import { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Colors, Spacing, Radius } from '@/constants/theme';
import { useHealthStore } from '@/store/health.store';
import { savePatientProfile, saveFamilyHistory, loadPatientProfile } from '@/services/auth.service';

const HK_PERMISSIONS = [
  { icon: '❤️', label: 'Heart rate & HRV' },
  { icon: '🩸', label: 'Blood pressure' },
  { icon: '🍬', label: 'Blood glucose' },
  { icon: '🫁', label: 'Oxygen saturation' },
  { icon: '⚖️', label: 'Weight & BMI' },
  { icon: '👣', label: 'Steps & activity' },
  { icon: '🌡️', label: 'Body temperature' },
  { icon: '😴', label: 'Sleep analysis' },
];

// ICD-10 code → relationship map from step3 params
const CONDITION_LABELS: Record<string, string> = {
  E11: 'Type 2 Diabetes',
  I10: 'Hypertension',
  I25: 'Coronary artery disease',
  I63: 'Stroke',
  C18: 'Colorectal cancer',
  E78: 'High cholesterol',
};

export default function Step4() {
  const params        = useLocalSearchParams();
  const setPatient    = useHealthStore(s => s.setPatient);
  const [loading, setLoading] = useState(false);

  const finish = async (withHealthKit: boolean) => {
    setLoading(true);
    try {
      // 1. Save patient profile to Supabase
      const patientId = await savePatientProfile({
        firstName:     String(params.firstName ?? ''),
        dateOfBirth:   String(params.dob ?? ''),
        sex:           String(params.sex ?? 'other'),
        heightCm:      parseFloat(String(params.heightCm ?? '0')),
        weightKg:      parseFloat(String(params.weightKg ?? '0')),
        bloodType:     String(params.bloodType ?? ''),
        smokingStatus: String(params.smoking ?? 'never'),
        activityLevel: String(params.activity ?? 'light'),
      });

      if (!patientId) throw new Error('Failed to save profile');

      // 2. Save family history conditions
      const familyConds: string[] = params.familyConds
        ? JSON.parse(String(params.familyConds))
        : [];

      if (familyConds.length > 0) {
        await saveFamilyHistory(
          patientId,
          familyConds.map(code => ({
            conditionCode:    code,
            conditionDisplay: CONDITION_LABELS[code] ?? code,
            relationship:     'first_degree_relative',
          }))
        );
      }

      // 3. Load full profile into store
      const profile = await loadPatientProfile();
      if (profile) setPatient(profile);

      // 4. Navigate to dashboard
      // HealthKit sync will auto-run via useHealthSync on mount
      router.replace('/(tabs)');
    } catch (err: any) {
      Alert.alert('Setup failed', err.message ?? 'Please try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <View style={styles.progress}>
        {[1,2,3,4].map(i => (
          <View key={i} style={[styles.dot, styles.dotActive]} />
        ))}
      </View>

      <Text style={styles.eyebrow}>Step 4 of 4</Text>
      <Text style={styles.title}>Connect Apple Health</Text>
      <Text style={styles.sub}>
        MedAI reads your biometrics to generate risk insights. We never write to HealthKit or share your data.
      </Text>

      <View style={styles.permCard}>
        <Text style={styles.permTitle}>Read-only access requested:</Text>
        {HK_PERMISSIONS.map((p, i) => (
          <View key={i} style={styles.permRow}>
            <Text style={styles.permIcon}>{p.icon}</Text>
            <Text style={styles.permLabel}>{p.label}</Text>
            <Text style={styles.permCheck}>✓</Text>
          </View>
        ))}
      </View>

      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          🔐 Encrypted · EU servers (Frankfurt) · GDPR Art. 9{'\n'}
          ⚕️ Risk indicators only, not medical diagnoses{'\n'}
          🗑️ Delete all data anytime in Settings
        </Text>
      </View>

      {loading ? (
        <View style={styles.loadingRow}>
          <ActivityIndicator color={Colors.blue} />
          <Text style={styles.loadingText}>Saving your profile...</Text>
        </View>
      ) : (
        <>
          <TouchableOpacity style={styles.btnPrimary} onPress={() => finish(true)}>
            <Text style={styles.btnPrimaryText}>Connect Apple Health</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.btnSecondary} onPress={() => finish(false)}>
            <Text style={styles.btnSecondaryText}>Skip — enter data manually</Text>
          </TouchableOpacity>
        </>
      )}

      <TouchableOpacity style={styles.back} onPress={() => router.back()}>
        <Text style={styles.backText}>← Back</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:             { flex: 1, backgroundColor: Colors.bg },
  scroll:           { padding: Spacing.lg, paddingTop: 56, paddingBottom: 40 },
  progress:         { flexDirection: 'row', gap: 6, marginBottom: Spacing.lg },
  dot:              { flex: 1, height: 3, borderRadius: 2, backgroundColor: Colors.bgLift },
  dotActive:        { backgroundColor: Colors.green },
  eyebrow:          { fontSize: 10, color: Colors.textSub, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 8, fontFamily: 'monospace' },
  title:            { fontSize: 26, fontWeight: '700', color: Colors.text, marginBottom: 8, letterSpacing: -0.5 },
  sub:              { fontSize: 13, color: Colors.textSub, lineHeight: 20, marginBottom: Spacing.xl },
  permCard:         { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.md },
  permTitle:        { fontSize: 10, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', marginBottom: Spacing.sm },
  permRow:          { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.04)' },
  permIcon:         { fontSize: 16, width: 24 },
  permLabel:        { flex: 1, fontSize: 13, color: Colors.textSub, fontFamily: 'monospace' },
  permCheck:        { fontSize: 12, color: Colors.green },
  disclaimer:       { backgroundColor: 'rgba(255,61,92,0.05)', borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(255,61,92,0.15)', marginBottom: Spacing.xl },
  disclaimerText:   { fontSize: 11, color: Colors.textSub, lineHeight: 19 },
  loadingRow:       { flexDirection: 'row', alignItems: 'center', gap: 12, justifyContent: 'center', padding: Spacing.lg },
  loadingText:      { color: Colors.textSub, fontSize: 12, fontFamily: 'monospace' },
  btnPrimary:       { backgroundColor: Colors.blue, borderRadius: Radius.md, padding: 16, alignItems: 'center', marginBottom: Spacing.sm },
  btnPrimaryText:   { color: '#fff', fontSize: 15, fontWeight: '700', fontFamily: 'monospace' },
  btnSecondary:     { borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, alignItems: 'center', marginBottom: Spacing.sm },
  btnSecondaryText: { color: Colors.textSub, fontSize: 13, fontFamily: 'monospace' },
  back:             { alignItems: 'center', marginTop: Spacing.sm },
  backText:         { color: Colors.textSub, fontSize: 12, fontFamily: 'monospace' },
});
