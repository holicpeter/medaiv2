import { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, TextInput,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Colors, Spacing, Radius } from '@/constants/theme';

const SMOKING_OPTS = [
  { value: 'never',   label: 'Never smoked' },
  { value: 'former',  label: 'Former smoker' },
  { value: 'current', label: 'Current smoker' },
];
const ACTIVITY_OPTS = [
  { value: 'sedentary',  label: 'Sedentary',      desc: '< 1 hour / week' },
  { value: 'light',      label: 'Light',           desc: '1–3 hours / week' },
  { value: 'moderate',   label: 'Moderate',        desc: '3–5 hours / week' },
  { value: 'active',     label: 'Active',          desc: '5–7 hours / week' },
  { value: 'very_active',label: 'Very active',     desc: '2× / day' },
];
const FAMILY_CONDITIONS = [
  { code: 'E11', label: 'Type 2 Diabetes' },
  { code: 'I10', label: 'Hypertension' },
  { code: 'I25', label: 'Coronary artery disease' },
  { code: 'I63', label: 'Stroke' },
  { code: 'C18', label: 'Colorectal cancer' },
  { code: 'E78', label: 'High cholesterol' },
];

export default function Step3() {
  const params                        = useLocalSearchParams();
  const [smoking, setSmoking]         = useState('never');
  const [activity, setActivity]       = useState('light');
  const [familyConds, setFamilyConds] = useState<string[]>([]);

  const toggleCond = (code: string) =>
    setFamilyConds(prev =>
      prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]
    );

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <View style={styles.progress}>
        {[1,2,3,4].map(i => (
          <View key={i} style={[styles.dot, i <= 3 && styles.dotActive]} />
        ))}
      </View>

      <Text style={styles.eyebrow}>Step 3 of 4</Text>
      <Text style={styles.title}>Lifestyle & family history</Text>
      <Text style={styles.sub}>These are among the strongest predictors of chronic disease risk.</Text>

      {/* Smoking */}
      <Text style={styles.label}>Smoking status</Text>
      {SMOKING_OPTS.map(o => (
        <TouchableOpacity
          key={o.value}
          style={[styles.optRow, smoking === o.value && styles.optRowActive]}
          onPress={() => setSmoking(o.value)}
        >
          <View style={[styles.radio, smoking === o.value && styles.radioActive]} />
          <Text style={[styles.optLabel, smoking === o.value && styles.optLabelActive]}>
            {o.label}
          </Text>
        </TouchableOpacity>
      ))}

      {/* Activity */}
      <Text style={styles.label}>Physical activity</Text>
      {ACTIVITY_OPTS.map(o => (
        <TouchableOpacity
          key={o.value}
          style={[styles.optRow, activity === o.value && styles.optRowActive]}
          onPress={() => setActivity(o.value)}
        >
          <View style={[styles.radio, activity === o.value && styles.radioActive]} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.optLabel, activity === o.value && styles.optLabelActive]}>
              {o.label}
            </Text>
            <Text style={styles.optDesc}>{o.desc}</Text>
          </View>
        </TouchableOpacity>
      ))}

      {/* Family history */}
      <Text style={styles.label}>Family history (select all that apply)</Text>
      <Text style={styles.subLabel}>First-degree relatives (parents, siblings)</Text>
      <View style={styles.chips}>
        {FAMILY_CONDITIONS.map(c => (
          <TouchableOpacity
            key={c.code}
            style={[styles.chip, familyConds.includes(c.code) && styles.chipActive]}
            onPress={() => toggleCond(c.code)}
          >
            <Text style={[styles.chipText, familyConds.includes(c.code) && styles.chipTextActive]}>
              {familyConds.includes(c.code) ? '✓ ' : ''}{c.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={styles.btn}
        onPress={() => router.push({
          pathname: '/onboarding/step4',
          params: {
            ...params, smoking, activity,
            familyConds: JSON.stringify(familyConds),
          },
        })}
      >
        <Text style={styles.btnText}>Continue →</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.back} onPress={() => router.back()}>
        <Text style={styles.backText}>← Back</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:           { flex: 1, backgroundColor: Colors.bg },
  scroll:         { padding: Spacing.lg, paddingTop: 56, paddingBottom: 40 },
  progress:       { flexDirection: 'row', gap: 6, marginBottom: Spacing.lg },
  dot:            { flex: 1, height: 3, borderRadius: 2, backgroundColor: Colors.bgLift },
  dotActive:      { backgroundColor: Colors.blue },
  eyebrow:        { fontSize: 10, color: Colors.textSub, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 8, fontFamily: 'monospace' },
  title:          { fontSize: 26, fontWeight: '700', color: Colors.text, marginBottom: 8, letterSpacing: -0.5 },
  sub:            { fontSize: 13, color: Colors.textSub, lineHeight: 20, marginBottom: Spacing.xl },
  label:          { fontSize: 11, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8, marginTop: Spacing.lg },
  subLabel:       { fontSize: 10, color: Colors.textMuted, marginBottom: 10, marginTop: -4 },
  optRow:         { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 13, borderRadius: Radius.md, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, marginBottom: 6 },
  optRowActive:   { borderColor: Colors.blue, backgroundColor: 'rgba(59,139,255,0.08)' },
  radio:          { width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: Colors.textSub },
  radioActive:    { borderColor: Colors.blue, backgroundColor: Colors.blue },
  optLabel:       { fontSize: 13, color: Colors.textSub, fontFamily: 'monospace' },
  optLabelActive: { color: Colors.text, fontWeight: '700' },
  optDesc:        { fontSize: 10, color: Colors.textMuted, marginTop: 1 },
  chips:          { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip:           { paddingVertical: 9, paddingHorizontal: 12, borderRadius: Radius.sm, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border },
  chipActive:     { borderColor: Colors.purple, backgroundColor: 'rgba(155,109,255,0.12)' },
  chipText:       { fontSize: 11, color: Colors.textSub, fontFamily: 'monospace' },
  chipTextActive: { color: Colors.purple, fontWeight: '700' },
  btn:            { marginTop: Spacing.xl, backgroundColor: Colors.blue, borderRadius: Radius.md, padding: 16, alignItems: 'center' },
  btnText:        { color: '#fff', fontSize: 15, fontWeight: '700', fontFamily: 'monospace' },
  back:           { alignItems: 'center', marginTop: Spacing.md },
  backText:       { color: Colors.textSub, fontSize: 12, fontFamily: 'monospace' },
});
