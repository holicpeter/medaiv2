import { Stack } from 'expo-router';
export default function AuthLayout() {
  return (
    <Stack screenOptions={{
      headerShown: false,
      contentStyle: { backgroundColor: '#060910' },
      animation: 'fade',
    }} />
  );
}
