import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  ActivityIndicator, Alert,
} from 'react-native';
import { router } from 'expo-router';
import { Colors, Spacing, Radius } from '@/constants/theme';
import { signIn, signUp } from '@/services/auth.service';

export default function LoginScreen() {
  const [mode, setMode]       = useState<'login' | 'signup'>('login');
  const [email, setEmail]     = useState('');
  const [password, setPass]   = useState('');
  const [loading, setLoading] = useState(false);

  const canSubmit = email.includes('@') && password.length >= 8;

  const submit = async () => {
    setLoading(true);
    try {
      const result = mode === 'login'
        ? await signIn(email, password)
        : await signUp(email, password);

      if (!result.success) {
        Alert.alert('Error', result.error ?? 'Something went wrong');
        return;
      }

      if (mode === 'signup') {
        Alert.alert(
          'Check your email',
          'We sent a confirmation link. Click it to verify your account.',
          [{ text: 'OK', onPress: () => setMode('login') }]
        );
      } else {
        // Successful login — _layout will redirect based on session
        router.replace('/');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.inner}>
        {/* Logo */}
        <View style={styles.logoRow}>
          <View style={styles.logoIcon}>
            <Text style={{ fontSize: 22 }}>🩺</Text>
          </View>
          <View>
            <Text style={styles.logoName}>MedAI</Text>
            <Text style={styles.logoTagline}>Personal Health Intelligence</Text>
          </View>
        </View>

        <Text style={styles.title}>
          {mode === 'login' ? 'Welcome back' : 'Create account'}
        </Text>
        <Text style={styles.sub}>
          {mode === 'login'
            ? 'Sign in to access your health dashboard.'
            : 'Your data is encrypted and stored in EU servers.'}
        </Text>

        {/* Email */}
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="you@example.com"
          placeholderTextColor={Colors.textMuted}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />

        {/* Password */}
        <Text style={styles.label}>Password</Text>
        <TextInput
          style={styles.input}
          placeholder="Min. 8 characters"
          placeholderTextColor={Colors.textMuted}
          value={password}
          onChangeText={setPass}
          secureTextEntry
          autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
        />

        {/* Submit */}
        <TouchableOpacity
          style={[styles.btn, !canSubmit && styles.btnDisabled]}
          disabled={!canSubmit || loading}
          onPress={submit}
        >
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.btnText}>
                {mode === 'login' ? 'Sign in →' : 'Create account →'}
              </Text>
          }
        </TouchableOpacity>

        {/* Toggle mode */}
        <TouchableOpacity
          style={styles.toggle}
          onPress={() => setMode(mode === 'login' ? 'signup' : 'login')}
        >
          <Text style={styles.toggleText}>
            {mode === 'login'
              ? "Don't have an account? Sign up"
              : 'Already have an account? Sign in'}
          </Text>
        </TouchableOpacity>

        {/* GDPR note */}
        {mode === 'signup' && (
          <Text style={styles.gdpr}>
            🔒 By creating an account you agree to our Privacy Policy.
            Health data is encrypted (GDPR Art. 9) and never sold.
          </Text>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root:         { flex: 1, backgroundColor: Colors.bg },
  inner:        { flex: 1, padding: Spacing.lg, paddingTop: 72, justifyContent: 'center' },
  logoRow:      { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: Spacing.xl },
  logoIcon:     { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(59,139,255,0.15)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(59,139,255,0.3)' },
  logoName:     { fontSize: 18, fontWeight: '700', color: Colors.text, letterSpacing: -0.3 },
  logoTagline:  { fontSize: 10, color: Colors.textSub, fontFamily: 'monospace' },
  title:        { fontSize: 26, fontWeight: '700', color: Colors.text, letterSpacing: -0.5, marginBottom: 8 },
  sub:          { fontSize: 13, color: Colors.textSub, lineHeight: 20, marginBottom: Spacing.xl },
  label:        { fontSize: 11, color: Colors.textSub, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8, marginTop: Spacing.md },
  input:        { backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, fontSize: 15, color: Colors.text, fontFamily: 'monospace' },
  btn:          { marginTop: Spacing.xl, backgroundColor: Colors.blue, borderRadius: Radius.md, padding: 16, alignItems: 'center' },
  btnDisabled:  { opacity: 0.3 },
  btnText:      { color: '#fff', fontSize: 15, fontWeight: '700', fontFamily: 'monospace' },
  toggle:       { alignItems: 'center', marginTop: Spacing.lg },
  toggleText:   { color: Colors.blue, fontSize: 12, fontFamily: 'monospace' },
  gdpr:         { marginTop: Spacing.lg, fontSize: 10, color: Colors.textMuted, lineHeight: 16, textAlign: 'center' },
});
