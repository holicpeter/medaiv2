/**
 * Entry point — routing logic:
 *   No session       → auth/login
 *   Session, no patient profile → onboarding/step1
 *   Session + profile complete  → (tabs)
 */
import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useAuthStore } from '@/store/auth.store';
import { useHealthStore } from '@/store/health.store';
import { loadPatientProfile } from '@/services/auth.service';
import { Colors } from '@/constants/theme';

export default function Index() {
  const loading    = useAuthStore(s => s.loading);
  const session    = useAuthStore(s => s.session);
  const patient    = useHealthStore(s => s.patient);
  const setPatient = useHealthStore(s => s.setPatient);

  useEffect(() => {
    if (loading) return;

    if (!session) {
      router.replace('/auth/login');
      return;
    }

    // Session exists — load patient profile
    loadPatientProfile().then(profile => {
      if (!profile) {
        // New user — go to onboarding
        router.replace('/onboarding/step1');
        return;
      }
      // Check if profile is complete (has firstName)
      if (!profile.firstName) {
        router.replace('/onboarding/step1');
        return;
      }
      setPatient(profile);
      router.replace('/(tabs)');
    });
  }, [loading, session]);

  // Show spinner while resolving auth state
  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }}>
      <ActivityIndicator color={Colors.blue} size="large" />
    </View>
  );
}
