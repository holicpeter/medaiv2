import { createClient } from '@supabase/supabase-js';
import type { Observation, RiskScore, AIInsight } from '../models/health.types';

const URL  = process.env.EXPO_PUBLIC_SUPABASE_URL  ?? '';
const ANON = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

export const supabase = createClient(URL, ANON, {
  auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});

export async function upsertObservations(
  patientId: string,
  obs: Omit<Observation, 'id' | 'patientId'>[]
) {
  const rows = obs.map(o => ({
    patient_id:         patientId,
    loinc_code:         o.loincCode,
    display_name:       o.displayName,
    category:           o.category,
    value_quantity:     o.valueQuantity,
    unit:               o.unit,
    ref_low:            o.refLow,
    ref_high:           o.refHigh,
    flag:               o.flag,
    source:             o.source,
    effective_datetime: o.effectiveDatetime,
  }));
  const { error } = await supabase
    .from('observations')
    .upsert(rows, { onConflict: 'patient_id,loinc_code,effective_datetime' });
  if (error) throw new Error(error.message);
}

export async function getLatestObservations(patientId: string, days = 30) {
  const since = new Date();
  since.setDate(since.getDate() - days);
  const { data, error } = await supabase
    .from('observations')
    .select('*')
    .eq('patient_id', patientId)
    .gte('effective_datetime', since.toISOString())
    .is('deleted_at', null)
    .order('effective_datetime', { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function saveRiskScore(score: Omit<RiskScore, 'id'>) {
  const { error } = await supabase.from('risk_scores').insert({
    patient_id:           score.patientId,
    condition_code:       score.conditionCode,
    condition_display:    score.conditionDisplay,
    probability:          score.probability,
    risk_tier:            score.riskTier,
    confidence:           score.confidence,
    horizon_months:       score.horizonMonths,
    contributing_factors: score.contributingFactors,
    disclaimer:           score.disclaimer,
    model_version:        'claude-reasoner-v1.2',
    model_type:           'claude_llm',
  });
  if (error) throw new Error(error.message);
}

export async function saveInsight(insight: Omit<AIInsight, 'id'>) {
  const { error } = await supabase.from('ai_insights').insert({
    patient_id:   insight.patientId,
    insight_type: insight.insightType,
    priority:     insight.priority,
    title:        insight.title,
    body:         insight.body,
    action_items: insight.actionItems,
    disclaimer:   insight.disclaimer,
  });
  if (error) throw new Error(error.message);
}

export async function saveSync(
  patientId: string,
  data: {
    source: string;
    status: string;
    syncedFrom: string;
    syncedTo: string;
    observationsCount: number;
    errorsCount: number;
    errorDetails: string[];
    durationMs: number;
  }
) {
  const { error } = await supabase.from('sync_logs').insert({
    patient_id:          patientId,
    source:              data.source,
    status:              data.status,
    synced_from:         data.syncedFrom,
    synced_to:           data.syncedTo,
    observations_count:  data.observationsCount,
    errors_count:        data.errorsCount,
    error_details:       data.errorDetails,
    duration_ms:         data.durationMs,
  });
  if (error) throw new Error(error.message);
}
