/**
 * MedAI — HealthKit Sync Service
 * Reads biometrics from Apple HealthKit → normalizes to FHIR
 * → upserts to Supabase observations table
 *
 * Uses: react-native-health (requires Expo Dev Client, not Expo Go)
 *
 * Install:
 *   npm install react-native-health
 *   npx expo install expo-build-properties
 *   npx expo prebuild   ← generates ios/ folder
 *   cd ios && pod install
 */

import AppleHealthKit, {
  HealthKitPermissions,
  HealthInputOptions,
  HealthValue,
} from 'react-native-health';
import { upsertObservations, saveSync } from './supabase';
import type { Observation, ObservationFlag } from '../models/health.types';

// ── LOINC mapping ─────────────────────────────────────────

const LOINC: Record<string, {
  loinc: string;
  display: string;
  unit: string;
  category: Observation['category'];
  refLow?: number;
  refHigh?: number;
}> = {
  HeartRate:              { loinc: '8867-4',  display: 'Heart Rate',            unit: 'bpm',        category: 'vital-signs', refLow: 60,  refHigh: 100  },
  HeartRateVariability:   { loinc: '80404-7', display: 'Heart Rate Variability', unit: 'ms',         category: 'vital-signs'                               },
  RestingHeartRate:       { loinc: '40443-4', display: 'Resting Heart Rate',     unit: 'bpm',        category: 'vital-signs', refLow: 60,  refHigh: 100  },
  BloodPressureSystolic:  { loinc: '8480-6',  display: 'Systolic BP',           unit: 'mmHg',       category: 'vital-signs', refLow: 90,  refHigh: 129  },
  BloodPressureDiastolic: { loinc: '8462-4',  display: 'Diastolic BP',          unit: 'mmHg',       category: 'vital-signs', refLow: 60,  refHigh: 89   },
  BloodGlucose:           { loinc: '2339-0',  display: 'Blood Glucose',         unit: 'mg/dL',      category: 'laboratory',  refLow: 70,  refHigh: 99   },
  OxygenSaturation:       { loinc: '2708-6',  display: 'Oxygen Saturation',     unit: '%',          category: 'vital-signs', refLow: 95,  refHigh: 100  },
  BodyTemperature:        { loinc: '8310-5',  display: 'Body Temperature',      unit: 'Cel',        category: 'vital-signs', refLow: 36.1,refHigh: 37.2 },
  Weight:                 { loinc: '29463-7', display: 'Body Weight',           unit: 'kg',         category: 'vital-signs'                               },
  Height:                 { loinc: '8302-2',  display: 'Body Height',           unit: 'cm',         category: 'vital-signs'                               },
  BodyMassIndex:          { loinc: '39156-5', display: 'BMI',                   unit: 'kg/m2',      category: 'vital-signs', refLow: 18.5,refHigh: 24.9 },
  StepCount:              { loinc: '55423-8', display: 'Step Count',            unit: 'steps',      category: 'activity',    refLow: 10000              },
  ActiveEnergyBurned:     { loinc: '41981-2', display: 'Active Energy Burned',  unit: 'kcal',       category: 'activity'                                  },
  RespiratoryRate:        { loinc: '9279-1',  display: 'Respiratory Rate',      unit: 'breaths/min',category: 'vital-signs', refLow: 12,  refHigh: 20   },
};

// ── Permissions ───────────────────────────────────────────

const PERMISSIONS: HealthKitPermissions = {
  permissions: {
    read: [
      AppleHealthKit.Constants.Permissions.HeartRate,
      AppleHealthKit.Constants.Permissions.HeartRateVariability,
      AppleHealthKit.Constants.Permissions.RestingHeartRate,
      AppleHealthKit.Constants.Permissions.BloodPressureDiastolic,
      AppleHealthKit.Constants.Permissions.BloodPressureSystolic,
      AppleHealthKit.Constants.Permissions.BloodGlucose,
      AppleHealthKit.Constants.Permissions.OxygenSaturation,
      AppleHealthKit.Constants.Permissions.BodyTemperature,
      AppleHealthKit.Constants.Permissions.Weight,
      AppleHealthKit.Constants.Permissions.Height,
      AppleHealthKit.Constants.Permissions.BodyMassIndex,
      AppleHealthKit.Constants.Permissions.StepCount,
      AppleHealthKit.Constants.Permissions.ActiveEnergyBurned,
      AppleHealthKit.Constants.Permissions.RespiratoryRate,
    ],
    write: [],
  },
};

// ── Flag calculation ──────────────────────────────────────

function calcFlag(value: number, meta: typeof LOINC[string]): ObservationFlag {
  const { refLow, refHigh } = meta;
  if (refHigh !== undefined && value > refHigh * 1.2) return 'HH';
  if (refHigh !== undefined && value > refHigh)       return 'H';
  if (refLow  !== undefined && value < refLow  * 0.8) return 'LL';
  if (refLow  !== undefined && value < refLow)        return 'L';
  return 'N';
}

// ── Sample → Observation ──────────────────────────────────

function toObs(
  type: string,
  sample: HealthValue,
  patientId: string,
  valueOverride?: number
): Omit<Observation, 'id' | 'patientId'> {
  const meta = LOINC[type]!;
  const value = valueOverride ?? (sample.value as number);
  return {
    loincCode:         meta.loinc,
    displayName:       meta.display,
    category:          meta.category,
    valueQuantity:     value,
    unit:              meta.unit,
    refLow:            meta.refLow,
    refHigh:           meta.refHigh,
    flag:              calcFlag(value, meta),
    source:            'apple_healthkit',
    effectiveDatetime: sample.startDate,
  };
}

// ── Individual fetchers ───────────────────────────────────

const makeOptions = (daysBack: number): HealthInputOptions => {
  const start = new Date();
  start.setDate(start.getDate() - daysBack);
  return {
    startDate: start.toISOString(),
    endDate:   new Date().toISOString(),
    ascending: false,
    limit:     500,
  };
};

function fetchSamples<T extends HealthValue>(
  fn: (opts: HealthInputOptions, cb: (err: string, results: T[]) => void) => void,
  opts: HealthInputOptions
): Promise<T[]> {
  return new Promise((resolve, reject) =>
    fn(opts, (err, results) => err ? reject(new Error(err)) : resolve(results))
  );
}

// ── Main sync function ────────────────────────────────────

export interface SyncResult {
  success:    boolean;
  syncedAt:   string;
  count:      number;
  byType:     Record<string, number>;
  errors:     string[];
  durationMs: number;
}

let _initialized = false;

async function ensureInitialized(): Promise<boolean> {
  if (_initialized) return true;
  return new Promise(resolve => {
    AppleHealthKit.initHealthKit(PERMISSIONS, err => {
      if (err) { console.error('[HK] init error:', err); resolve(false); }
      else     { _initialized = true; resolve(true); }
    });
  });
}

export async function syncHealthKit(
  patientId: string,
  daysBack = 30
): Promise<SyncResult> {
  const start = Date.now();
  const errors: string[] = [];
  const allObs: Omit<Observation, 'id' | 'patientId'>[] = [];
  const byType: Record<string, number> = {};
  const opts = makeOptions(daysBack);

  const ok = await ensureInitialized();
  if (!ok) {
    return {
      success: false, syncedAt: new Date().toISOString(),
      count: 0, byType: {}, errors: ['HealthKit permission denied'], durationMs: Date.now() - start,
    };
  }

  // Helper to run a fetcher safely
  const run = async (
    label: string,
    fetcher: () => Promise<Omit<Observation, 'id' | 'patientId'>[]>
  ) => {
    try {
      const obs = await fetcher();
      allObs.push(...obs);
      if (obs.length) byType[label] = obs.length;
    } catch (e: any) {
      errors.push(`${label}: ${e.message}`);
    }
  };

  await Promise.allSettled([

    run('HeartRate', async () => {
      const s = await fetchSamples(AppleHealthKit.getHeartRateSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('HeartRate', x, patientId));
    }),

    run('RestingHeartRate', async () => {
      const s = await fetchSamples(AppleHealthKit.getRestingHeartRate.bind(AppleHealthKit), opts);
      return s.map(x => toObs('RestingHeartRate', x, patientId));
    }),

    run('HeartRateVariability', async () => {
      const s = await fetchSamples(AppleHealthKit.getHeartRateVariabilitySamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('HeartRateVariability', x, patientId));
    }),

    run('BloodPressure', async () => {
      const s = await fetchSamples<any>(AppleHealthKit.getBloodPressureSamples.bind(AppleHealthKit), opts);
      const result: Omit<Observation, 'id' | 'patientId'>[] = [];
      s.forEach(x => {
        result.push(toObs('BloodPressureSystolic',  x, patientId, x.bloodPressureSystolicValue));
        result.push(toObs('BloodPressureDiastolic', x, patientId, x.bloodPressureDiastolicValue));
      });
      return result;
    }),

    run('BloodGlucose', async () => {
      const s = await fetchSamples(AppleHealthKit.getBloodGlucoseSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('BloodGlucose', x, patientId));
    }),

    run('OxygenSaturation', async () => {
      const s = await fetchSamples(AppleHealthKit.getOxygenSaturationSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('OxygenSaturation', x, patientId, (x.value as number) * 100));
    }),

    run('BodyTemperature', async () => {
      const s = await fetchSamples(AppleHealthKit.getBodyTemperatureSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('BodyTemperature', x, patientId));
    }),

    run('Weight', async () => {
      const s = await fetchSamples(AppleHealthKit.getWeightSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('Weight', x, patientId));
    }),

    run('StepCount', async () => {
      const s = await fetchSamples(AppleHealthKit.getDailyStepCountSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('StepCount', x, patientId));
    }),

    run('ActiveEnergy', async () => {
      const s = await fetchSamples(AppleHealthKit.getActiveEnergyBurned.bind(AppleHealthKit), opts);
      return s.map(x => toObs('ActiveEnergyBurned', x, patientId));
    }),

    run('RespiratoryRate', async () => {
      const s = await fetchSamples(AppleHealthKit.getRespiratoryRateSamples.bind(AppleHealthKit), opts);
      return s.map(x => toObs('RespiratoryRate', x, patientId));
    }),

  ]);

  // Sort newest first
  allObs.sort((a, b) =>
    new Date(b.effectiveDatetime).getTime() - new Date(a.effectiveDatetime).getTime()
  );

  // Batch upsert to Supabase (max 500 per call)
  const BATCH = 500;
  for (let i = 0; i < allObs.length; i += BATCH) {
    try {
      await upsertObservations(patientId, allObs.slice(i, i + BATCH));
    } catch (e: any) {
      errors.push(`upsert batch ${i}: ${e.message}`);
    }
  }

  const result: SyncResult = {
    success:    errors.length === 0,
    syncedAt:   new Date().toISOString(),
    count:      allObs.length,
    byType,
    errors,
    durationMs: Date.now() - start,
  };

  // Log sync to Supabase
  try {
    await saveSync(patientId, {
      source:             'apple_healthkit',
      status:             result.success ? 'success' : errors.length < allObs.length ? 'partial' : 'failed',
      syncedFrom:         makeOptions(daysBack).startDate!,
      syncedTo:           new Date().toISOString(),
      observationsCount:  result.count,
      errorsCount:        errors.length,
      errorDetails:       errors,
      durationMs:         result.durationMs,
    });
  } catch { /* non-fatal */ }

  return result;
}

// ── Latest value helpers (from Supabase view) ─────────────

export function getLatestByLoinc(
  observations: Observation[],
  loincCode: string
): Observation | null {
  return observations
    .filter(o => o.loincCode === loincCode)
    .sort((a, b) => new Date(b.effectiveDatetime).getTime() - new Date(a.effectiveDatetime).getTime())
    [0] ?? null;
}

export function computeTrend(
  observations: Observation[],
  loincCode: string,
  days: number
): number | null {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);

  const sorted = observations
    .filter(o => o.loincCode === loincCode)
    .sort((a, b) => new Date(a.effectiveDatetime).getTime() - new Date(b.effectiveDatetime).getTime());

  const recent = sorted.filter(o => new Date(o.effectiveDatetime) >= cutoff);
  const older  = sorted.filter(o => new Date(o.effectiveDatetime) < cutoff);

  if (!recent.length || !older.length) return null;

  const recentAvg = recent.reduce((s, o) => s + o.valueQuantity, 0) / recent.length;
  const olderAvg  = older.reduce((s, o) =>  s + o.valueQuantity, 0) / older.length;

  return olderAvg === 0 ? null : ((recentAvg - olderAvg) / olderAvg) * 100;
}
