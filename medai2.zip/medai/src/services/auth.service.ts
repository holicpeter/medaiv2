/**
 * MedAI — Auth Service
 * Wraps Supabase Auth for email/password login + session management
 *
 * Flow:
 *   signUp   → Supabase creates auth.users row
 *            → DB trigger creates public.users + public.patients
 *            → confirmation email sent (configurable in Supabase dashboard)
 *   signIn   → returns session with JWT
 *   session  → persisted in SecureStore via @supabase/supabase-js
 */

import { supabase } from './supabase';
import type { Session, User } from '@supabase/supabase-js';

export interface AuthResult {
  success: boolean;
  user?:   User;
  session?: Session;
  error?:  string;
}

// ── Sign up ───────────────────────────────────────────────
export async function signUp(
  email: string,
  password: string
): Promise<AuthResult> {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) return { success: false, error: error.message };
  return { success: true, user: data.user ?? undefined, session: data.session ?? undefined };
}

// ── Sign in ───────────────────────────────────────────────
export async function signIn(
  email: string,
  password: string
): Promise<AuthResult> {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { success: false, error: error.message };
  return { success: true, user: data.user, session: data.session };
}

// ── Sign out ──────────────────────────────────────────────
export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

// ── Current session ───────────────────────────────────────
export async function getSession(): Promise<Session | null> {
  const { data } = await supabase.auth.getSession();
  return data.session;
}

// ── Load patient profile for current user ─────────────────
export async function loadPatientProfile() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('patients')
    .select('*')
    .eq('user_id', user.id)
    .single();

  if (error || !data) return null;

  return {
    id:            data.id as string,
    userId:        data.user_id as string,
    firstName:     data.first_name as string | undefined,
    dateOfBirth:   data.date_of_birth as string | undefined,
    sex:           data.gender as 'male' | 'female' | 'other' | undefined,
    bloodType:     data.blood_type as string | undefined,
    heightCm:      data.height_cm as number | undefined,
    weightKg:      data.weight_kg as number | undefined,
    smokingStatus: (data.smoking_status ?? 'unknown') as any,
    activityLevel: (data.activity_level ?? 'unknown') as any,
  };
}

// ── Save patient profile after onboarding ─────────────────
export async function savePatientProfile(profile: {
  firstName:     string;
  dateOfBirth:   string;
  sex:           string;
  heightCm:      number;
  weightKg:      number;
  bloodType:     string;
  smokingStatus: string;
  activityLevel: string;
}): Promise<string | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('patients')
    .update({
      first_name:     profile.firstName,
      date_of_birth:  profile.dateOfBirth || null,
      gender:         profile.sex,
      height_cm:      profile.heightCm || null,
      weight_kg:      profile.weightKg || null,
      blood_type:     profile.bloodType || null,
      smoking_status: profile.smokingStatus,
      activity_level: profile.activityLevel,
      updated_at:     new Date().toISOString(),
    })
    .eq('user_id', user.id)
    .select('id')
    .single();

  if (error || !data) {
    console.error('[auth] savePatientProfile:', error?.message);
    return null;
  }
  return data.id as string;
}

// ── Save family history ────────────────────────────────────
export async function saveFamilyHistory(
  patientId: string,
  entries: { conditionCode: string; conditionDisplay: string; relationship: string }[]
): Promise<void> {
  if (!entries.length) return;
  const rows = entries.map(e => ({
    patient_id:        patientId,
    relationship:      e.relationship,
    condition_code:    e.conditionCode,
    condition_display: e.conditionDisplay,
    risk_weight:       0.5,
  }));
  await supabase.from('family_history').upsert(rows, {
    onConflict: 'patient_id,condition_code,relationship',
  });
}
