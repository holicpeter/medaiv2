import { create } from 'zustand';
import type { Patient, Observation, RiskScore, AIInsight } from '../models/health.types';

interface HealthState {
  patient:         Patient | null;
  setPatient:      (p: Patient) => void;
  observations:    Observation[];
  setObservations: (o: Observation[]) => void;
  lastSyncedAt:    string | null;
  setLastSynced:   (t: string) => void;
  riskScores:      RiskScore[];
  setRiskScores:   (r: RiskScore[]) => void;
  insights:        AIInsight[];
  setInsights:     (i: AIInsight[]) => void;
  dismissInsight:  (id: string) => void;
  syncing:         boolean;
  setSyncing:      (v: boolean) => void;
  analysing:       boolean;
  setAnalysing:    (v: boolean) => void;
}

export const useHealthStore = create<HealthState>((set) => ({
  patient:         null,
  setPatient:      (patient)       => set({ patient }),
  observations:    [],
  setObservations: (observations)  => set({ observations }),
  lastSyncedAt:    null,
  setLastSynced:   (lastSyncedAt)  => set({ lastSyncedAt }),
  riskScores:      [],
  setRiskScores:   (riskScores)    => set({ riskScores }),
  insights:        [],
  setInsights:     (insights)      => set({ insights }),
  dismissInsight:  (id) => set(s => ({
    insights: s.insights.map(i =>
      i.id === id ? { ...i, dismissedAt: new Date().toISOString() } : i
    ),
  })),
  syncing:         false,
  setSyncing:      (syncing)       => set({ syncing }),
  analysing:       false,
  setAnalysing:    (analysing)     => set({ analysing }),
}));
