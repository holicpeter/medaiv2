import { create } from 'zustand';
import type { Session, User } from '@supabase/supabase-js';

interface AuthState {
  session:    Session | null;
  user:       User | null;
  loading:    boolean;
  setSession: (s: Session | null) => void;
  setUser:    (u: User | null) => void;
  setLoading: (v: boolean) => void;
  clear:      () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  session:    null,
  user:       null,
  loading:    true,
  setSession: (session) => set({ session }),
  setUser:    (user)    => set({ user }),
  setLoading: (loading) => set({ loading }),
  clear:      ()        => set({ session: null, user: null }),
}));
