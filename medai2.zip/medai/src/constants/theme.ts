export const Colors = {
  bg:        '#060910',
  bgCard:    '#0c1018',
  bgLift:    '#111620',
  border:    'rgba(255,255,255,0.07)',
  borderHi:  'rgba(255,255,255,0.14)',
  text:      '#e8edf5',
  textSub:   '#5a6578',
  textMuted: '#2e3847',
  green:     '#22d3a0',
  yellow:    '#f5c518',
  orange:    '#ff7d3b',
  red:       '#ff3b5c',
  blue:      '#3b8bff',
  purple:    '#9b6dff',
} as const;

export const Risk = {
  low:      '#22d3a0',
  moderate: '#f5c518',
  elevated: '#ff7d3b',
  high:     '#ff3b5c',
  critical: '#ff0033',
} as const;

export const Spacing = {
  xs: 4, sm: 8, md: 14, lg: 20, xl: 28, xxl: 40,
} as const;

export const Radius = {
  sm: 8, md: 12, lg: 16, xl: 24, full: 999,
} as const;
