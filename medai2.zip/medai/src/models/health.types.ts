export type FHIRCategory = 'vital-signs' | 'laboratory' | 'activity' | 'social-history';
export type ObservationFlag = 'N' | 'H' | 'L' | 'HH' | 'LL';
export type ObservationSource = 'apple_healthkit' | 'manual' | 'ocr_import';
export type RiskTier = 'low' | 'moderate' | 'elevated' | 'high' | 'critical';
export type Confidence = 'low' | 'medium' | 'high';

export interface Observation {
  id:                string;
  patientId:         string;
  loincCode:         string;
  displayName:       string;
  category:          FHIRCategory;
  valueQuantity:     number;
  unit:              string;
  refLow?:           number;
  refHigh?:          number;
  flag:              ObservationFlag;
  source:            ObservationSource;
  effectiveDatetime: string;
}

export interface RiskScore {
  id:                  string;
  patientId:           string;
  conditionCode:       string;
  conditionDisplay:    string;
  probability:         number;
  riskTier:            RiskTier;
  confidence:          Confidence;
  horizonMonths:       number;
  contributingFactors: ContributingFactor[];
  explanation:         string;
  disclaimer:          string;
  calculatedAt:        string;
}

export interface ContributingFactor {
  factor:     string;
  loincCode?: string;
  direction:  'increases_risk' | 'decreases_risk';
  weight:     number;
  modifiable: boolean;
}

export interface AIInsight {
  id:           string;
  patientId:    string;
  insightType:  'risk_explanation' | 'trend_alert' | 'recommendation' | 'weekly_summary' | 'anomaly';
  priority:     'critical' | 'warning' | 'info' | 'positive';
  title:        string;
  body:         string;
  actionItems:  ActionItem[];
  confidence:   Confidence;
  disclaimer:   string;
  createdAt:    string;
  shownAt?:     string;
  dismissedAt?: string;
}

export interface ActionItem {
  action:        string;
  category:      'diet' | 'exercise' | 'monitoring' | 'consult_doctor' | 'lifestyle';
  urgency:       'immediate' | 'this_week' | 'this_month' | 'ongoing';
  evidenceNote?: string;
}

export interface Patient {
  id:            string;
  userId:        string;
  firstName?:    string;
  dateOfBirth?:  string;
  sex?:          'male' | 'female' | 'other';
  bloodType?:    string;
  heightCm?:     number;
  weightKg?:     number;
  smokingStatus: 'never' | 'former' | 'current' | 'unknown';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active' | 'unknown';
}

export interface OnboardingData {
  firstName:     string;
  dateOfBirth:   string;
  sex:           'male' | 'female' | 'other';
  heightCm:      number;
  weightKg:      number;
  bloodType:     string;
  smokingStatus: Patient['smokingStatus'];
  activityLevel: Patient['activityLevel'];
  familyHistory: FamilyHistoryEntry[];
  healthkitConsent: boolean;
}

export interface FamilyHistoryEntry {
  relationship:     string;
  conditionDisplay: string;
  conditionCode:    string;
  onsetAge?:        number;
}
