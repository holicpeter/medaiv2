/**
 * useHealthSync — orchestrates full sync lifecycle:
 *   1. Ensure patient profile exists in Supabase
 *   2. Run HealthKit sync
 *   3. Load latest observations into Zustand store
 *   4. Trigger clinical-reasoner if fresh data
 */
import { useCallback, useEffect, useRef } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { syncHealthKit, type SyncResult } from '../services/healthkit.sync';
import { getLatestObservations } from '../services/supabase';
import { useHealthStore } from '../store/health.store';

const SYNC_INTERVAL_MS = 15 * 60 * 1000; // 15 minutes

export function useHealthSync() {
  const patient      = useHealthStore(s => s.patient);
  const setSyncing   = useHealthStore(s => s.setSyncing);
  const setObs       = useHealthStore(s => s.setObservations);
  const setLastSync  = useHealthStore(s => s.setLastSynced);
  const lastSyncedAt = useHealthStore(s => s.lastSyncedAt);
  const lastSyncRef  = useRef<number>(0);

  const sync = useCallback(async (force = false): Promise<SyncResult | null> => {
    if (!patient?.id) return null;

    const now = Date.now();
    if (!force && now - lastSyncRef.current < SYNC_INTERVAL_MS) return null;

    setSyncing(true);
    try {
      const result = await syncHealthKit(patient.id, 30);
      lastSyncRef.current = now;

      if (result.count > 0 || force) {
        // Refresh observations from Supabase (authoritative source)
        const rows = await getLatestObservations(patient.id, 30);
        const mapped = rows.map((r: any) => ({
          id:                r.id,
          patientId:         r.patient_id,
          loincCode:         r.loinc_code,
          displayName:       r.display_name,
          category:          r.category,
          valueQuantity:     r.value_quantity,
          unit:              r.unit,
          refLow:            r.ref_low,
          refHigh:           r.ref_high,
          flag:              r.flag,
          source:            r.source,
          effectiveDatetime: r.effective_datetime,
        }));
        setObs(mapped);
        setLastSync(result.syncedAt);
      }

      return result;
    } catch (err) {
      console.error('[useHealthSync]', err);
      return null;
    } finally {
      setSyncing(false);
    }
  }, [patient?.id]);

  // Sync on mount
  useEffect(() => {
    sync(true);
  }, [patient?.id]);

  // Sync when app comes to foreground
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state: AppStateStatus) => {
      if (state === 'active') sync();
    });
    return () => sub.remove();
  }, [sync]);

  return { sync };
}
